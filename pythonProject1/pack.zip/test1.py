from pyspark import SparkConf, SparkContext
from pyspark.sql import SparkSession

def main():
    #import spark.implicits._
    df= spark.read.option("header","true").csv("D:\\BD_Data\\Raw_Data\\txns_head")
    df.show()

if __name__=="__main__" :
#    conf = SparkConf().setAppName("spark").setMaster("local[*]")
#    sc = SparkContext(conf)
#    sc.setLogLevel("Error")
    spark = SparkSession.builder.master("local[*]").appName("spark").getOrCreate()
    main()
